# Block Blast + Агент Пуля

Две браузерные игры с общим сервером аккаунтов и рейтинга.

## Игры

1. **Block Blast** — классика: ставь блоки, очищай линии, комбо.
2. **Агент Пуля** — головоломка в стиле Agent Bullet: кликай, чтобы выстрелить, считай рикошеты, порази всех врагов.

## Структура

```
block-blast/
├── app.py
├── requirements.txt
├── README.md
├── static/
│   ├── block-blast.html
│   └── agent-bullet.html
├── blockblast.db      (создаётся сам)
└── secret.key         (создаётся сам)
```

## Запуск

```bash
pip install -r requirements.txt
python app.py
```

Открой **http://localhost:5000** — появится меню выбора игр.

- Block Blast: http://localhost:5000/block-blast.html  
- Агент Пуля: http://localhost:5000/agent-bullet.html  

## Продакшен

```bash
gunicorn -w 2 -b 0.0.0.0:8000 app:app
```
