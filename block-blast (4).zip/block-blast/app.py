"""
Block Blast — сервер регистрации, авторизации и общего рейтинга (Python + Flask).

Структура проекта:
    block-blast/
    ├── app.py
    ├── requirements.txt
    ├── README.md
    ├── static/
    │   └── block-blast.html
    ├── blockblast.db          (создаётся автоматически)
    └── secret.key             (создаётся автоматически)

Запуск (разработка):
    pip install -r requirements.txt
    python app.py
    # или: PORT=8080 python app.py

    Откройте http://localhost:5000

Продакшен:
    gunicorn -w 2 -b 0.0.0.0:8000 app:app
"""

from __future__ import annotations

import os
import re
import secrets
import sqlite3
import time
from collections import defaultdict, deque

from flask import Flask, g, jsonify, request, send_from_directory
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer
from werkzeug.security import check_password_hash, generate_password_hash

BASE = os.path.dirname(os.path.abspath(__file__))
STATIC = os.path.join(BASE, "static")
DB_PATH = os.path.join(BASE, "blockblast.db")
KEY_PATH = os.path.join(BASE, "secret.key")

TOKEN_TTL = 30 * 24 * 3600  # 30 дней
MAX_SCORE = 2_000_000
# буквы (в т.ч. кириллица), цифры, пробел, _ и -
NAME_RE = re.compile(r"^[\w\- ]{3,16}$", re.UNICODE)


def load_secret() -> str:
    if os.environ.get("SECRET_KEY"):
        return os.environ["SECRET_KEY"]
    if not os.path.exists(KEY_PATH):
        with open(KEY_PATH, "w", encoding="utf-8") as f:
            f.write(secrets.token_hex(32))
    with open(KEY_PATH, encoding="utf-8") as f:
        return f.read().strip()


app = Flask(__name__, static_folder=STATIC, static_url_path="")
app.config["MAX_CONTENT_LENGTH"] = 4096
signer = URLSafeTimedSerializer(load_secret(), salt="bb-auth")


# ---------- база данных ----------
def get_db() -> sqlite3.Connection:
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db


@app.teardown_appcontext
def close_db(_: object) -> None:
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def init_db() -> None:
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                k       TEXT PRIMARY KEY,          -- никнейм в нижнем регистре
                name    TEXT NOT NULL,
                pw      TEXT NOT NULL,             -- werkzeug (scrypt / pbkdf2)
                best    INTEGER NOT NULL DEFAULT 0,
                games   INTEGER NOT NULL DEFAULT 0,
                created REAL NOT NULL
            )
            """
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_best ON users(best DESC, created)"
        )


# ---------- помощники ----------
def err(msg: str, code: int = 400):
    return jsonify(error=msg), code


def rank_of(row: sqlite3.Row) -> int:
    if row["best"] <= 0:
        return 0
    cnt = (
        get_db()
        .execute(
            "SELECT COUNT(*) FROM users "
            "WHERE best > ? OR (best = ? AND created < ?)",
            (row["best"], row["best"], row["created"]),
        )
        .fetchone()[0]
    )
    return cnt + 1


def mine(row: sqlite3.Row) -> dict:
    return {
        "name": row["name"],
        "best": row["best"],
        "games": row["games"],
        "rank": rank_of(row),
    }


def current_user() -> sqlite3.Row | None:
    auth = request.headers.get("Authorization", "")
    token = auth.removeprefix("Bearer ").strip()
    if not token:
        return None
    try:
        k = signer.loads(token, max_age=TOKEN_TTL)
    except (BadSignature, SignatureExpired):
        return None
    return get_db().execute("SELECT * FROM users WHERE k=?", (k,)).fetchone()


# простой in-memory rate-limit: ≤20 попыток входа/регистрации за 10 минут с IP
_attempts: dict[str, deque] = defaultdict(deque)


def too_many_attempts() -> bool:
    now = time.time()
    q = _attempts[request.remote_addr or "unknown"]
    while q and now - q[0] > 600:
        q.popleft()
    q.append(now)
    return len(q) > 20


# ---------- страницы ----------
@app.get("/")
def index():
    # стартовое меню выбора игр (лежит в agent-bullet.html)
    return send_from_directory(STATIC, "agent-bullet.html")


@app.get("/block-blast.html")
def block_blast():
    return send_from_directory(STATIC, "block-blast.html")


@app.get("/agent-bullet.html")
def agent_bullet():
    return send_from_directory(STATIC, "agent-bullet.html")


# ---------- API ----------
@app.get("/api/ping")
def ping():
    return jsonify(ok=True)


@app.post("/api/register")
def register():
    if too_many_attempts():
        return err("Слишком много попыток, подождите несколько минут", 429)

    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()
    pw = str(data.get("password", ""))

    if not NAME_RE.match(name):
        return err("Никнейм: 3–16 символов — буквы, цифры, пробел, _ и -")
    if not 6 <= len(pw) <= 100:
        return err("Пароль — минимум 6 символов")

    k = name.lower()
    try:
        get_db().execute(
            "INSERT INTO users(k, name, pw, created) VALUES(?,?,?,?)",
            (k, name, generate_password_hash(pw), time.time()),
        )
        get_db().commit()
    except sqlite3.IntegrityError:
        return err("Этот никнейм уже занят", 409)

    row = get_db().execute("SELECT * FROM users WHERE k=?", (k,)).fetchone()
    return jsonify(token=signer.dumps(k), **mine(row))


@app.post("/api/login")
def login():
    if too_many_attempts():
        return err("Слишком много попыток, подождите несколько минут", 429)

    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()
    pw = str(data.get("password", ""))

    row = get_db().execute("SELECT * FROM users WHERE k=?", (name.lower(),)).fetchone()
    if not row or not check_password_hash(row["pw"], pw):
        return err("Неверный никнейм или пароль", 401)

    return jsonify(token=signer.dumps(row["k"]), **mine(row))


@app.get("/api/me")
def me():
    u = current_user()
    if not u:
        return err("Нужно войти заново", 401)
    return jsonify(mine(u))


@app.post("/api/score")
def score():
    u = current_user()
    if not u:
        return err("Нужно войти заново", 401)

    raw = (request.get_json(silent=True) or {}).get("score")
    if isinstance(raw, bool) or not isinstance(raw, int) or not 0 < raw <= MAX_SCORE:
        return err("Некорректный счёт")

    get_db().execute(
        "UPDATE users SET games = games + 1, best = MAX(best, ?) WHERE k = ?",
        (raw, u["k"]),
    )
    get_db().commit()

    row = get_db().execute("SELECT * FROM users WHERE k=?", (u["k"],)).fetchone()
    return jsonify(mine(row))


@app.get("/api/top")
def top():
    lim = max(1, min(100, request.args.get("limit", 50, type=int)))
    rows = (
        get_db()
        .execute(
            "SELECT name, best, games FROM users "
            "WHERE best > 0 ORDER BY best DESC, created LIMIT ?",
            (lim,),
        )
        .fetchall()
    )
    u = current_user()
    return jsonify(
        top=[
            {"rank": i + 1, "name": r["name"], "best": r["best"], "games": r["games"]}
            for i, r in enumerate(rows)
        ],
        me=mine(u) if u else None,
    )


@app.errorhandler(404)
def not_found(_: object):
    return err("Не найдено", 404)


@app.errorhandler(413)
def too_big(_: object):
    return err("Слишком большой запрос", 413)


init_db()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"Block Blast → http://localhost:{port}")
    app.run(host="0.0.0.0", port=port, debug=False)
